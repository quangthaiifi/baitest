# java7-web-rest-springboot1 

REST application based on Spring Boot 
